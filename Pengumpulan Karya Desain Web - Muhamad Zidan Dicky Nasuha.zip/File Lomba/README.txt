Desain web ini merupakan karya dari Muhamad Zidan Dicky Nasuha dari Universitas Sebelas Maret.
Fitur yang dimiliki oleh desain web ini adalah :

1. Memiliki beberapa fitur animasi masuk
2. Merupakan web yang sudah memiliki fitur responsive
3. Memiliki fitur navbar yang bisa berubah menjadi sidebar
4. Memiliki desain yang memanjakan mata
5. Terdapat 4 subweb dengan keunikan tersendiri

Konsep desain yang dimiliki web ini adalah konsep desain yang ramah dan tidak terlalu banyak tambahan yang tidak diperlukan. Untuk teknologi yang digunakan dalam membuat web ini, saya hanya menggunakan Visual Studio Code.
Cara mengakses web ini adalah membuka file index.html untuk diarahkan menuju halaman utama dari web.

Terimakasih